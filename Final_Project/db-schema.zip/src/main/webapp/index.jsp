<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Assignment Planner</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-LtrjvnR4/Jgk4h6v8IHbU5eEbFf5S6xN1vVU5VU5GId4EBXPRVx5IgaNMMf0nQ2c" crossorigin="anonymous" />
</head>
<body>
<div class="container mt-5">
    <div class="jumbotron">
        <h1 class="display-4">Assignment Planner</h1>
        <p class="lead">Track tasks, deadlines, priorities, and rewards in a simple student-friendly planner.</p>
        <hr class="my-4" />
        <a class="btn btn-primary btn-lg" href="${pageContext.request.contextPath}/assignments?action=list" role="button">Open Assignment Checklist</a>
    </div>
</div>
</body>
</html>
